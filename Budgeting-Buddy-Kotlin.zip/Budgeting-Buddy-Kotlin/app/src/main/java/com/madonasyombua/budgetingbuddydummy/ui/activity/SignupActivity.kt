package com.madonasyombua.budgetingbuddydummy.ui.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

import com.madonasyombua.budgetingbuddydummy.R

class SignupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)


    }
}
