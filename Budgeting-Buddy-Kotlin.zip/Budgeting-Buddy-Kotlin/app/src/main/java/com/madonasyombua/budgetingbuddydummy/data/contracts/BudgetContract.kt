package com.madonasyombua.budgetingbuddydummy.data.contracts

class BudgetContract
